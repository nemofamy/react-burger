const OrderFeedPage = () => {
    return (
        <>
            <p>OrderFeedPage</p>
        </>
    );
}

export default OrderFeedPage;